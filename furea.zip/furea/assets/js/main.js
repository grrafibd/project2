
// countdown plugin:
$(document).ready(function(){

    $('#example').countdown({
        date: '12/24/2022 23:59:59'
        }, function () {
          alert('thank you');
        });
    

    });



    $('.one-time').slick({
      dots: false,
      slidesToShow: 3,
      slidesToScroll: 1, 
      variableWidth: true,
      prevArrow:".left_angle",
      easing:'easeInSine',

      nextArrow:".right_angle", 
      touchMove: false
    });
    
    $('.testimonial_carosel').slick({
      dots: true,
      slidesToShow: 3,
      slidesToScroll: 1, 
      variableWidth: true,
      prevArrow:"",
      nextArrow:"", 
      autoplay: true,
      touchMove: false
    });



    
    $('.blog_carosel').slick({
      dots: false,
      slidesToShow: 3,
      slidesToScroll: 1, 
      variableWidth: true,
      prevArrow:".blog_left_angle",
      easing:'easeInSine',

      nextArrow:".blog_right_angle", 
      touchMove: false
    });

    $('.footer_img_carosel').slick({
      dots: false,
      slidesToShow: 5,
      prevArrow:".footer_angle_left",
      slidesToScroll: 1, 
      nextArrow:".footer_angle_right", 
      touchMove: false
    });

    $(window).scroll(function() {
      if ($(this).scrollTop() > 600) {
        $(".scrollup").fadeIn();
      } else {
        $(".scrollup").fadeOut();
      }
    })

    $(".scrollup").click(function() {
      $("html, body").animate({
        scrollTop: 0
      }, 600);
      return false;
    })


// start expend search icon
$(function(){

    // wow js plugin
    new WOW().init(); 

    // mixitup plugin
    var mixer = mixitup('.mixerx');




    
    var submitIcon = $('.searchbox-icon');
    var inputBox = $('.searchbox-input');
    var searchBox = $('.searchbox');
    var isOpen = false;
    submitIcon.click(function(){
        if(isOpen == false){
            searchBox.addClass('searchbox-open');
            inputBox.focus();
            isOpen = true;
        } else {
            searchBox.removeClass('searchbox-open');
            inputBox.focusout();
            isOpen = false;
        }
    });  
     submitIcon.mouseup(function(){
            return false;
        });
    searchBox.mouseup(function(){
            return false;
        });
    $(document).mouseup(function(){
            if(isOpen == true){
                $('.searchbox-icon').css('display','block');
                submitIcon.click();
            }
        });
});
    function buttonUp(){
        var inputVal = $('.searchbox-input').val();
        inputVal = $.trim(inputVal).length;
        if( inputVal !== 0){
            $('.searchbox-icon').css('display','none');
        } else {
            $('.searchbox-input').val('');
            $('.searchbox-icon').css('display','block');
        }
    }
    // end expend search bar

// jquery call
    new UISearch( document.getElementById( 'sb-search' ) );



